#include <vector>
#include <iostream>
using namespace std;
const int N = 6;
const int INF = 99999;
vector<vector<int>> Dijkstra(double Graph[N][N], int startVertex);
int main()
{
	double Graph[N][N] = {
		// 0  1  2  3  4  5
		 { 0, 2, 4, 0, 0, 0 }, /* 0 */
		 { 0, 0, 1, 4, 2, 0 }, /* 1 */
		 { 0, 0, 0, 0, 3, 0 }, /* 2 */
		 { 0, 0, 0, 0, 0, 2 }, /* 3 */
		 { 0, 0, 0, 3, 0, 2 }, /* 4 */
		 { 0, 0, 0, 0, 0, 0 }  /* 5 */
	};
	vector<vector<int>> results = Dijkstra(Graph, 0);
	int finalVertex;
	cout << "Enter the vertex you want to reach: ";
	cin >> finalVertex;

	for (int i = 0; i < results[finalVertex].size(); i++)
		cout << results[finalVertex][i] << " ";
	return 0;
}
vector<vector<int>> Dijkstra(double Graph[N][N], int startVertex)
{
	bool done[N];
	int previous[N];
	double cost[N];

	double temp[N][N];
	for (int i = 0; i < N; i++)
		for (int j = 0; j < N; j++)
			if (Graph[i][j] == 0)
				temp[i][j] = INF;
			else
				temp[i][j] = Graph[i][j];

	// 1st Row:
	for (int i = 0; i < N; i++)
	{
		if (i == startVertex)
		{
			done[i] = true;
			previous[i] = -1;
			cost[i] = 0;
		}
		else
		{
			done[i] = false;
			previous[i] = startVertex;
			cost[i] = temp[startVertex][i];
		}
	}
	// Today
	int count = 1;
	while (count < N)
	{
		// Which vertex is done?
		// Vertex with the lowest cost.
		double minimum = INF;
		int currentVertex;
		for (int i = 0; i < N; i++)
		{
			if (done[i] == false && cost[i] < minimum)
			{
				minimum = cost[i];
				currentVertex = i;
			}
		}
		done[currentVertex] = true;
		//
		for (int i = 0; i < N; i++)
		{
			if (done[i] == false)
			{
				double value = cost[currentVertex] + temp[currentVertex][i];
				if (value < cost[i])
				{
					cost[i] = value;
					previous[i] = currentVertex;
				}
			}
		}
		count++;
	}
	vector<vector<int>> paths;
	paths.resize(N);
	int j;
	for (int i = 0; i < N; i++)
	{
		paths[i].push_back(i);
		j = i;
		while (j != startVertex)
		{
			paths[i].insert(paths[i].begin(), previous[j]);
			j = previous[j];
		}
	}
	return paths;
}